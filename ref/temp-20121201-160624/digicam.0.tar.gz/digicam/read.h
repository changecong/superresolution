#ifndef Read_h
#define Read_h


void readblock(unsigned int n, unsigned int mduwide, int block[64]);


#endif
