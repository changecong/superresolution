#include "file.h"
#include "ReadBmp_aux.h"

#define MDU(size)   ((size+7)>>3)


typedef short WORD;
typedef long DWORD;
typedef char BYTE;

typedef struct tagBITMAPFILEHEADER {
	WORD bfType;
	DWORD bfSize;
	WORD bfReserved1;
	WORD bfReserved2;
	DWORD bfOffBits;
} BITMAPFILEHEADER;

typedef struct tagBITMAPINFOHEADER {
	/* BITMAP core header info -> OS/2 */
	DWORD biSize;
	DWORD biWidth;
	DWORD biHeight;
	WORD biPlanes;
	WORD biBitCount;

	/* BITMAP info -> Windows 3.1 */
	DWORD biCompression;
	DWORD biSizeImage;
	DWORD biXPelsPerMeter;
	DWORD biYPelsPerMeter;
	DWORD biClrUsed;
	DWORD biClrImportant;
} BITMAPINFOHEADER;

typedef struct tagRGBTRIPLE {
	BYTE B, G, R;
} RGBTRIPLE;


  FILE* ifp;
  BITMAPFILEHEADER BmpFileHeader;
  BITMAPINFOHEADER BmpInfoHeader;
  RGBTRIPLE *BmpColors;
  int BmpScanWidth, BmpScanHeight;

  unsigned char **ScanBuffer;
  
  int ReadRevWord()
  {
    int c;
    c = fgetc(ifp);
    c |= fgetc(ifp) << 8;
    
    return c;
  }

  int ReadWord()
  {
    int c;
    c = fgetc(ifp) << 8;
    c |= fgetc(ifp);

    return c;
  }

  int ReadByte()
  {
    return fgetc(ifp);
  }

  long ReadRevDWord()
  {
    long c;
    c = fgetc(ifp);
    c |= fgetc(ifp) << 8;
    c |= fgetc(ifp) << 16;
    c |= fgetc(ifp) << 24;
    
    return c;
  }

  long ReadDWord()
  {
    long c;
    c = fgetc(ifp) << 24;
    c |= fgetc(ifp) << 16;
    c |= fgetc(ifp) << 8;
    c |= fgetc(ifp);
    
    return c;
  }
    
  int  IsBmpFile()
  {
    int t = ('B'<<8) | 'M';
    int c;
    c = ReadWord();
    fseek(ifp, -2, 1);
    
    return t == c;
  }
  
  void ReadBmpHeader()
  {
    int i, count;

    if (!IsBmpFile()) {
      fprintf(stderr, "This file is not compatible with BMP format.\n");
      exit(1);
    }

    /* BMP file header */
    BmpFileHeader.bfType = ReadWord();
    BmpFileHeader.bfSize = ReadRevDWord();
    BmpFileHeader.bfReserved1 = ReadRevWord();
    BmpFileHeader.bfReserved2 = ReadRevWord();
    BmpFileHeader.bfOffBits = ReadRevDWord();

    /* BMP core info */
    BmpInfoHeader.biSize = ReadRevDWord();
    BmpInfoHeader.biWidth = ReadRevDWord();
    BmpInfoHeader.biHeight = ReadRevDWord();
    BmpInfoHeader.biPlanes = ReadRevWord();
    BmpInfoHeader.biBitCount = ReadRevWord();

    if (BmpInfoHeader.biSize > 12) {
      BmpInfoHeader.biCompression = ReadRevDWord();
      BmpInfoHeader.biSizeImage = ReadRevDWord();
      BmpInfoHeader.biXPelsPerMeter = ReadRevDWord();
      BmpInfoHeader.biYPelsPerMeter = ReadRevDWord();
      BmpInfoHeader.biClrUsed = ReadRevDWord();
      BmpInfoHeader.biClrImportant = ReadRevDWord();

      /* read RGBQUAD */
      count = BmpFileHeader.bfOffBits - ftell(ifp);
      count >>= 2;
      
      BmpColors = (RGBTRIPLE*) calloc(sizeof(RGBTRIPLE), count);
      
      for (i=0; i<count; i++) {
	BmpColors[i].B = ReadByte();
	BmpColors[i].G = ReadByte();
	BmpColors[i].R = ReadByte();
	ReadByte();
      }
    }
    else {
      /* read RGBTRIPLE */
      count = BmpFileHeader.bfOffBits - ftell(ifp);
      count /= 3;
      
      BmpColors = (RGBTRIPLE*) calloc(sizeof(RGBTRIPLE), count);
      
      for (i=0; i<count; i++) {
	BmpColors[i].B = ReadByte();
	BmpColors[i].G = ReadByte();
	BmpColors[i].R = ReadByte();
      }
    }

    /* BMP scan line is aligned by LONG boundary */
    if (BmpInfoHeader.biBitCount == 24) {
      BmpScanWidth = ((BmpInfoHeader.biWidth*3 + 3) >> 2) << 2;
      BmpScanHeight = BmpInfoHeader.biHeight;
    }
    else {
      BmpScanWidth = ((BmpInfoHeader.biWidth + 3) >> 2) << 2;
      BmpScanHeight = BmpInfoHeader.biHeight;
    }
  }
    
  
unsigned int ReadBmp(unsigned int *imagewidth, unsigned int *imageheight) 
{	
      unsigned int i, r;
      unsigned int mduwide, mduhigh;

      // Open file
      ifp = fopen("ccd.bmp", "rb");
      if (!ifp) {
        fprintf(stderr, "Cannot open input file %s\n", "ccd.bmp");
        exit(1);
      }

      // Read BMP file header
      ReadBmpHeader();

      // get number of MDUs (8x8 blocks)
      *imagewidth  = BmpInfoHeader.biWidth;
      *imageheight = BmpInfoHeader.biHeight;
      mduwide = MDU(*imagewidth);
      mduhigh = MDU(*imageheight);

      // allocate two-dimensional array for the picture
      ScanBuffer = malloc(mduhigh * 8 * sizeof(char*));
      if(!ScanBuffer) {
        fprintf(stderr, "Out of memory\n");
        fclose (ifp);
        exit(1);
      }
      for (r = 0; r < mduhigh * 8; r++) {
	ScanBuffer[r] = malloc(mduwide * 8 * sizeof(char));
	if(!ScanBuffer[r]) {
	  fprintf(stderr, "Out of memory\n");
          fclose (ifp);
	  exit(1);
	}
      }

      // Loop over rows
      for (r = 0; r < BmpInfoHeader.biHeight; r++) 
      {
        // Position file pointer to corresponding row
        fseek (ifp, BmpFileHeader.bfOffBits + (BmpInfoHeader.biHeight - r - 1) * BmpScanWidth, 0);
        
        // Read pixel row
        if (ferror(ifp) || (fread(ScanBuffer[r], 1, BmpInfoHeader.biWidth, ifp) != BmpInfoHeader.biWidth)){
          fprintf(stderr, "Error reading data from file %s\n", "ccd.bmp");
          fclose (ifp);
          exit(1);
        }

	// fill remaining overhang pixels	
        for(i = BmpInfoHeader.biWidth; i < MDU(BmpInfoHeader.biWidth) * 8; i++) {
           ScanBuffer[r][i] = ScanBuffer[r][BmpInfoHeader.biWidth-1];
        }
    }
    
    fclose (ifp);

    return mduwide * mduhigh;
}

