#ifndef _DCT_h
#define _DCT_h


void dct(int in_block[64], int out_block[64]);


#endif
