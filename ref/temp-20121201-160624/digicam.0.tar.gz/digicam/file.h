#ifndef File_h
#define File_h

#include <stdio.h>
#include <stdlib.h>

void FileWrite(unsigned char *bytes, unsigned long num);

#endif
