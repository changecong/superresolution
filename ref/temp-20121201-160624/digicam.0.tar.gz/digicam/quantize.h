#ifndef _Quantize_h
#define _Quantize_h


extern int LuminanceQuantization[64];

void quantize(int in_block[64], int out_block[64]);


#endif
