#ifndef _ReadBmp_aux_h
#define _ReadBmp_aux_h

extern unsigned char **ScanBuffer;

unsigned int ReadBmp(unsigned int *mduwide, unsigned int *mduhigh);


#endif
