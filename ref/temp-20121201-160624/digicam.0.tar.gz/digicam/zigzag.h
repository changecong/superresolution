#ifndef _Zigzag_h
#define _Zigzag_h

extern int ZigzagIndex[64];
extern int IZigzagIndex[64];

void zigzag(int in_block[64], int out_block[64]);


#endif
