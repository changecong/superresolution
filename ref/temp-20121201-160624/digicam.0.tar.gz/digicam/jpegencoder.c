#include "ReadBmp_aux.h"

#include "read.h"
#include "dct.h"
#include "quantize.h"
#include "zigzag.h"
#include "huffencode.h"


int main() {
	unsigned int iter, N;
	unsigned int imagewidth, imageheight;
	int dctin[64];
	int dctout[64];
	int quantizeout[64];
	int zigzagout[64];

	N = ReadBmp(&imagewidth, &imageheight);

	for (iter = 0; iter < N; iter++)
	{
		readblock(iter, imagewidth, dctin);
		dct(dctin, dctout);
		quantize(dctout,quantizeout);
		zigzag(quantizeout, zigzagout);
		huffencode(zigzagout, N, imagewidth, imageheight);
	}

	return 0;
}
