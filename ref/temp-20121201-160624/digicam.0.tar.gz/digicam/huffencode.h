#ifndef HuffEncode_h
#define HuffEncode_h

void huffencode(int in_block[64], unsigned int N,
                unsigned int imagewidth, unsigned int imageheight);

#endif
