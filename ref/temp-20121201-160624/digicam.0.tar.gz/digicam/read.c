#include "read.h"

#include "ReadBmp_aux.h"

#define MDU(size)   ((size+7)>>3)


void readblock(unsigned int n, unsigned int imagewidth, int block[64])
{
        int i, j;
	int x, y;

	x = (n % MDU(imagewidth)) << 3;
	y = (n / MDU(imagewidth)) << 3;
	
	for (i=0; i<8; i++) {
	  for (j=0; j<8; j++) {
	    block[i*8+j] = ScanBuffer[y+i][x+j];
	  } 
	} 
} 

